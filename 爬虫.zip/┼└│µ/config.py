MONGO_URL = 'localhost'
MONGO_DB = 'jqzx'
MONGO_TABLE = 'ai_daily'

STOPWORDS_PATH = './stopwords.dat'
CORPUS_PATH = './corpus'
IDF_PATH = './idf/idf.txt'
USER_DICT_PATH = './THUOCL_it.txt'
PAGE_NUM = 300